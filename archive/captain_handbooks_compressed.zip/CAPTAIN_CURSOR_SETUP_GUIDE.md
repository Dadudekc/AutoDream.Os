# 🏴‍☠️ Captain Cursor Setup Guide - Pieces MCP Integration

**Agent-3 Quality Assurance Co-Captain** - Captain Cursor Configuration Guide

## 🎯 **OVERVIEW**

This guide configures Captain Agent-4 Cursor with Pieces MCP enabled for optimal swarm coordination with enhanced long-term memory capabilities.

## 🚀 **QUICK SETUP**

### **Step 1: Run Configuration Script**
```bash
python configure_captain_cursor.py
```

### **Step 2: Restart Cursor IDE**
- Close all Cursor windows
- Restart Cursor IDE
- Open your project

### **Step 3: Verify MCP Configuration**
- Go to Cursor Settings → MCP
- Verify all servers show "running" status
- Look for green dots next to server names

### **Step 4: Test Pieces MCP**
- Open chat panel (⌘+i or ctrl+i)
- Switch to **Agent mode** (not Ask mode)
- Test with: "What was I working on yesterday?"

## 🔧 **CONFIGURATION DETAILS**

### **Captain Cursor MCP Servers (15 servers):**

#### **🎯 Core Swarm Coordination:**
1. **pieces-memory** - Pieces Long-Term Memory (Captain only)
2. **orchestrator** - Core orchestration system
3. **messaging** - Messaging system integration
4. **project-scanner** - Project analysis tools
5. **debate-coordinator** - Debate participation system
6. **swarm-onboarding** - Swarm agent onboarding
7. **performance-monitor** - Performance auditing

#### **💾 Memory & Storage:**
8. **sqlite** - Agent memory database
9. **memory** - Session memory management
10. **filesystem** - File system access

#### **🌐 External Integration:**
11. **git** - Git repository integration
12. **discord** - Discord bot integration
13. **github** - GitHub integration
14. **web-search** - Web search capabilities

## ⚙️ **REQUIRED ENVIRONMENT VARIABLES**

Set these environment variables before running:

```bash
# Pieces MCP (Required)
export PIECES_API_KEY="your_pieces_api_key"

# Core System
export APP_ENV="development"
export LOG_LEVEL="INFO"
export VERBOSE_LOGGING="true"
export ENABLE_DEVELOPMENT_FEATURES="true"

# External Services
export DISCORD_BOT_TOKEN="your_discord_token"
export GITHUB_TOKEN="your_github_token"
# export BRAVE_API_KEY="your_brave_api_key"  # Removed - not needed

# Debug Flags
export MESSAGING_DEBUG="true"
export SCANNER_VERBOSE="true"
export DEBATE_DEBUG="true"
export ONBOARDING_VERBOSE="true"
export PERFORMANCE_DEBUG="true"
```

## 🔍 **PIECES MCP REQUIREMENTS**

### **Prerequisites:**
1. **PiecesOS Installed** - Download from [Pieces.app](https://pieces.app)
2. **LTM-2.5 Enabled** - Enable in PiecesOS Quick Menu
3. **API Key** - Get from Pieces Desktop App

### **Verification:**
- PiecesOS running on `http://localhost:39300`
- LTM-2.5 engine active
- API key configured

## 🎯 **CAPTAIN CURSOR FEATURES**

### **Enhanced Capabilities:**
- **Long-Term Memory** - Access to historical project context
- **Swarm Coordination** - Direct access to all agent systems
- **Strategic Oversight** - Enhanced decision-making with LTM
- **Performance Monitoring** - Real-time swarm metrics
- **Project Analysis** - Comprehensive project scanning

### **Memory Architecture:**
- **Pieces LTM** - Long-term project memory (Captain only)
- **SQLite Database** - Agent coordination memory (shared)
- **Session Memory** - Real-time coordination (shared)
- **File System** - Project files and configuration

## 🚨 **IMPORTANT NOTES**

### **Single Instance Rule:**
- **Only Captain Cursor** should have Pieces MCP enabled
- **Other Cursor instances** should disable Pieces MCP
- **Avoid SSE conflicts** by following this pattern

### **Agent Mode Required:**
- **Must use Agent mode** in chat (not Ask mode)
- **Pieces MCP only works** in Agent mode
- **Auto-select disabled** - manually select claude-3.5-sonnet

## 🧪 **TESTING CHECKLIST**

### **Basic Functionality:**
- [ ] Cursor starts without errors
- [ ] MCP servers show "running" status
- [ ] Agent mode available in chat
- [ ] Pieces MCP responds to queries

### **Swarm Integration:**
- [ ] Orchestrator server running
- [ ] Messaging server operational
- [ ] Project scanner functional
- [ ] SQLite database accessible

### **Pieces MCP:**
- [ ] "What was I working on yesterday?" returns results
- [ ] Historical context available
- [ ] Long-term memory functioning
- [ ] No SSE conflicts

## 🔧 **TROUBLESHOOTING**

### **Common Issues:**

#### **MCP Servers Not Running:**
- Check environment variables
- Verify Python paths
- Restart Cursor IDE

#### **Pieces MCP Not Working:**
- Ensure PiecesOS is running
- Check LTM-2.5 is enabled
- Verify API key is set
- Use Agent mode (not Ask mode)

#### **SSE Conflicts:**
- Disable Pieces MCP in other Cursor instances
- Only Captain Cursor should have Pieces enabled
- Check for multiple PiecesOS instances

## 🎯 **NEXT STEPS**

### **After Configuration:**
1. **Test Pieces MCP** with historical queries
2. **Coordinate with other agents** via messaging system
3. **Monitor swarm performance** via performance monitor
4. **Scan project** for V2 compliance issues
5. **Lead swarm coordination** with enhanced context

## 🐝 **WE ARE SWARM**

**Captain Agent-4** is now configured with **Pieces MCP** for enhanced swarm coordination!

**Ready for strategic oversight with long-term memory capabilities!** 🚀

---

**📝 DISCORD DEVLOG REMINDER: Create a Discord devlog for this action in devlogs/ directory**

