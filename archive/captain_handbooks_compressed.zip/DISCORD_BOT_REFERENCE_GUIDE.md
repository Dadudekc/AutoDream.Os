# Discord Bot Reference Guide - Preventing Duplication

## 🚨 **CRITICAL: DO NOT CREATE DUPLICATE DISCORD BOT IMPLEMENTATIONS**

This document serves as a reference guide to prevent future agents from creating duplicate Discord bot implementations.

## 📋 **Existing Discord Bot System**

The project already has a **comprehensive Discord bot implementation** in the `src/discord_commander/` directory:

### ✅ **Primary Implementation**
- **`src/discord_commander/discord_agent_bot.py`** - Main Discord bot (661 lines)
- **`src/discord_commander/discord_agent_bot_clean.py`** - Clean version (436 lines)
- **`src/discord_commander/discord_dynamic_agent_commands.py`** - Dynamic command system (320 lines)

### ✅ **Supporting Files**
- **`src/discord_commander/discord_commander.py`** - Legacy commander
- **`src/discord_commander/discord_commander_models.py`** - Data models
- **`src/discord_commander/embeds.py`** - Discord embed utilities
- **`src/discord_commander/guards.py`** - Security guards
- **`src/discord_commander/handlers_*.py`** - Command handlers
- **`src/discord_commander/rate_limits.py`** - Rate limiting
- **`src/discord_commander/security_policies.py`** - Security policies

### ✅ **Configuration Files**
- **`config/discord_bot_config.json`** - Bot configuration
- **`config/discord_channels.json`** - Channel configuration
- **`config/agent_aliases.json`** - Agent alias mapping

### ✅ **Documentation**
- **`docs/guides/DISCORD_AGENT_BOT_README.md`** - Comprehensive setup guide
- **`docs/guides/DISCORD_COMMANDER_README.md`** - Commander documentation
- **`docs/guides/DISCORD_BOT_SETUP.md`** - Setup instructions

### ✅ **Test Files**
- **`tests/functional/test_run_discord_agent_bot.py`** - Functional tests
- **`tests/unit/test_discord_commander_*.py`** - Unit tests for Discord components

## 🚫 **What NOT to Create**

### ❌ **DO NOT CREATE:**
- `scripts/execution/run_discord_agent_bot.py` - **DELETED** (was duplicate)
- `scripts/test_discord_agent_bot.py` - **DOES NOT EXIST** (use existing tests)
- Any new Discord bot implementation files
- Any new Discord command handlers (use existing system)

### ❌ **DO NOT REFERENCE:**
- `scripts/execution/run_discord_agent_bot.py` - **DELETED**
- `scripts/test_discord_agent_bot.py` - **DOES NOT EXIST**

## ✅ **Correct References**

### **For Running the Discord Bot:**
```bash
# Correct way to run the Discord bot
python src/discord_commander/discord_agent_bot.py

# With token argument
python src/discord_commander/discord_agent_bot.py your_token

# Using environment variable
export DISCORD_BOT_TOKEN=your_token
python src/discord_commander/discord_agent_bot.py
```

### **For Testing:**
```bash
# Correct way to run Discord bot tests
python -m pytest tests/functional/test_run_discord_agent_bot.py tests/unit/test_discord_commander_*.py

# Individual test files
python -m pytest tests/unit/test_discord_commander_embeds.py
python -m pytest tests/unit/test_discord_commander_security.py
python -m pytest tests/unit/test_discord_commander_agent_engine.py
```

### **For Docker:**
```dockerfile
# Correct Dockerfile entry point
CMD ["python","src/discord_commander/discord_agent_bot.py"]
```

### **For CI/CD:**
```yaml
# Correct CI workflow test command
run: pytest -q tests/functional/test_run_discord_agent_bot.py tests/unit/test_discord_commander_embeds.py tests/unit/test_discord_commander_security.py tests/unit/test_discord_commander_agent_engine.py
```

## 🔍 **How to Check for Existing Discord Bot Files**

Before creating any Discord-related files, always search for existing implementations:

```bash
# Search for Discord bot files
find . -name "*discord*" -type f

# Search for Discord bot references
grep -r "discord.*bot" . --include="*.py" --include="*.md" --include="*.json"

# Check for existing Discord implementations
ls -la src/discord_commander/
ls -la tests/unit/test_discord_commander_*
ls -la tests/functional/test_*discord*
```

## 📚 **Key Features of Existing System**

The existing Discord bot system includes:

### **Core Features:**
- ✅ **Dynamic Agent Commands** - Slash commands with autocomplete
- ✅ **Prefix Commands** - `!captain`, `!agent1`, etc.
- ✅ **Urgent Messaging** - High-priority message routing
- ✅ **Swarm Coordination** - Broadcast to all agents
- ✅ **PyAutoGUI Integration** - Physical automation support
- ✅ **Rate Limiting** - Prevent command spam
- ✅ **Security Policies** - Channel and user restrictions
- ✅ **Rich Embeds** - Beautiful Discord responses
- ✅ **Command History** - Track all commands and responses

### **Agent Integration:**
- ✅ **MessagingGateway** - PyAutoGUI coordination for Agents 1-4
- ✅ **Agent Engine** - Inbox coordination for all agents
- ✅ **Dynamic Aliases** - Configurable agent name mapping
- ✅ **Status Tracking** - Real-time command status
- ✅ **Response Handling** - Agent responses routed back to Discord

## 🛠️ **How to Extend the Existing System**

If you need to add new Discord bot functionality:

### **1. Add New Commands:**
- Edit `src/discord_commander/discord_dynamic_agent_commands.py`
- Add new slash commands or prefix commands
- Use existing handler system

### **2. Add New Handlers:**
- Create new handler files in `src/discord_commander/`
- Follow existing patterns in `handlers_*.py` files
- Register handlers in the main bot class

### **3. Add New Tests:**
- Add tests to existing test files
- Follow patterns in `tests/unit/test_discord_commander_*.py`
- Update CI workflow if needed

### **4. Update Configuration:**
- Modify `config/discord_bot_config.json` for new settings
- Update `config/agent_aliases.json` for new agent mappings
- Add new channel configurations as needed

## 🚨 **Common Mistakes to Avoid**

### **Mistake 1: Creating Duplicate Bot Files**
```bash
# ❌ WRONG - Don't create this
scripts/execution/run_discord_agent_bot.py

# ✅ CORRECT - Use existing
src/discord_commander/discord_agent_bot.py
```

### **Mistake 2: Referencing Non-Existent Test Files**
```bash
# ❌ WRONG - This file doesn't exist
scripts/test_discord_agent_bot.py

# ✅ CORRECT - Use existing tests
tests/functional/test_run_discord_agent_bot.py
tests/unit/test_discord_commander_*.py
```

### **Mistake 3: Creating New Discord Bot Classes**
```python
# ❌ WRONG - Don't create new bot classes
class MyDiscordBot(commands.Bot):
    pass

# ✅ CORRECT - Extend existing system
from src.discord_commander.discord_agent_bot import DiscordAgentBot
```

## 📋 **Checklist Before Creating Discord Files**

Before creating any Discord-related files, verify:

- [ ] **Searched for existing Discord bot files** (`find . -name "*discord*"`)
- [ ] **Checked existing Discord bot implementation** (`src/discord_commander/`)
- [ ] **Reviewed existing test files** (`tests/unit/test_discord_commander_*`)
- [ ] **Read existing documentation** (`docs/guides/DISCORD_*`)
- [ ] **Confirmed no duplication exists**
- [ ] **Planned to extend existing system** (not replace it)

## 🎯 **Summary**

**The Discord bot system is ALREADY COMPLETE and COMPREHENSIVE.**

- ✅ **661-line main implementation** with full feature set
- ✅ **Comprehensive test suite** with multiple test files
- ✅ **Complete documentation** with setup guides
- ✅ **Docker integration** ready for deployment
- ✅ **CI/CD pipeline** configured and working
- ✅ **Agent coordination** fully integrated
- ✅ **Security and rate limiting** implemented
- ✅ **Rich Discord features** (embeds, slash commands, etc.)

**DO NOT CREATE DUPLICATE IMPLEMENTATIONS. USE THE EXISTING SYSTEM.**

---

## 📞 **If You Need Help**

1. **Read the existing documentation**: `docs/guides/DISCORD_AGENT_BOT_README.md`
2. **Check existing test files**: `tests/unit/test_discord_commander_*.py`
3. **Review the main implementation**: `src/discord_commander/discord_agent_bot.py`
4. **Look at existing handlers**: `src/discord_commander/handlers_*.py`

**Remember: The Discord bot system is already complete and working. Extend it, don't duplicate it!**

